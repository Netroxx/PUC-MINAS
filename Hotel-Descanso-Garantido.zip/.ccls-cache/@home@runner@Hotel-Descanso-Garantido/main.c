#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct {
    int codigo;
    char nome[50];
    char endereco[100];
    char telefone[20];
} Cliente;

typedef struct {
    int codigo;
    char nome[50];
    char telefone[20];
    char cargo[30];
    float salario;
} Funcionario;

typedef struct {
    int numero;
    int quantidadeHospedes;
    float valorDiaria;
    char status[10]; // "ocupado" ou "desocupado"
} Quarto;

typedef struct {
    int codigo;
    char dataEntrada[11];
    char dataSaida[11];
    int quantidadeDiarias;
    int codigoCliente;
    int numeroQuarto;
} Estadia;

// Fun��es para garantir que os arquivos existam
void inicializarArquivos() {
    FILE *arquivo;

    // Arquivo de clientes
    arquivo = fopen("clientes.bin", "ab");
    if (arquivo == NULL) {
        printf("Erro ao criar o arquivo clientes.bin\n");
        exit(1);
    }
    fclose(arquivo);

    // Arquivo de funcion�rios
    arquivo = fopen("funcionarios.bin", "ab");
    if (arquivo == NULL) {
        printf("Erro ao criar o arquivo funcionarios.bin\n");
        exit(1);
    }
    fclose(arquivo);

    // Arquivo de quartos
    arquivo = fopen("quartos.bin", "ab");
    if (arquivo == NULL) {
        printf("Erro ao criar o arquivo quartos.bin\n");
        exit(1);
    }
    fclose(arquivo);

    // Arquivo de estadias
    arquivo = fopen("estadias.bin", "ab");
    if (arquivo == NULL) {
        printf("Erro ao criar o arquivo estadias.bin\n");
        exit(1);
    }
    fclose(arquivo);
}

// Fun��es para Manipula��o de Dados
void cadastrarCliente() {
    Cliente cliente;
    FILE *arquivo = fopen("clientes.bin", "ab+");

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo de clientes.\n");
        return;
    }

    printf("Codigo do cliente: ");
    scanf("%d", &cliente.codigo);

    // Verifica se o cliente j� existe
    Cliente clienteExistente;
    int clienteEncontrado = 0;
    while (fread(&clienteExistente, sizeof(Cliente), 1, arquivo)) {
        if (clienteExistente.codigo == cliente.codigo) {
            clienteEncontrado = 1;
            break;
        }
    }

    if (clienteEncontrado) {
        printf("Cliente j� cadastrado com este c�digo.\n");
        fclose(arquivo);
        return;
    }

    // Move o ponteiro de arquivo para o final para adicionar novo cliente
    fseek(arquivo, 0, SEEK_END);

    printf("Nome do cliente: ");
    scanf(" %[^\n]", cliente.nome);
    printf("Endereco do cliente: ");
    scanf(" %[^\n]", cliente.endereco);
    printf("Telefone do cliente: ");
    scanf(" %[^\n]", cliente.telefone);

    fwrite(&cliente, sizeof(Cliente), 1, arquivo);
    fclose(arquivo);
    printf("Cliente cadastrado com sucesso!\n");
}

void cadastrarFuncionario() {
    Funcionario funcionario;
    FILE *arquivo = fopen("funcionarios.bin", "ab+");

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo de funcion�rios.\n");
        return;
    }

    printf("Codigo do funcionario: ");
    scanf("%d", &funcionario.codigo);

    // Verifica se o funcion�rio j� existe
    Funcionario funcionarioExistente;
    int funcionarioEncontrado = 0;
    while (fread(&funcionarioExistente, sizeof(Funcionario), 1, arquivo)) {
        if (funcionarioExistente.codigo == funcionario.codigo) {
            funcionarioEncontrado = 1;
            break;
        }
    }

    if (funcionarioEncontrado) {
        printf("Funcion�rio j� cadastrado com este c�digo.\n");
        fclose(arquivo);
        return;
    }

    // Move o ponteiro de arquivo para o final para adicionar novo funcion�rio
    fseek(arquivo, 0, SEEK_END);

    printf("Nome do funcionario: ");
    scanf(" %[^\n]", funcionario.nome);
    printf("Telefone do funcionario: ");
    scanf(" %[^\n]", funcionario.telefone);
    printf("Cargo do funcionario: ");
    scanf(" %[^\n]", funcionario.cargo);
    printf("Sal�rio do funcionario: ");
    scanf("%f", &funcionario.salario);

    fwrite(&funcionario, sizeof(Funcionario), 1, arquivo);
    fclose(arquivo);
    printf("Funcionario cadastrado com sucesso!\n");
}

void cadastrarQuarto() {
    Quarto quarto;
    FILE *arquivo = fopen("quartos.bin", "ab+");

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo de quartos.\n");
        return;
    }

    printf("Numero do quarto: ");
    scanf("%d", &quarto.numero);

    // Verifica se o quarto j� existe
    Quarto quartoExistente;
    int quartoEncontrado = 0;
    while (fread(&quartoExistente, sizeof(Quarto), 1, arquivo)) {
        if (quartoExistente.numero == quarto.numero) {
            quartoEncontrado = 1;
            break;
        }
    }

    if (quartoEncontrado) {
        printf("Quarto j� cadastrado com este n�mero.\n");
        fclose(arquivo);
        return;
    }

    // Move o ponteiro de arquivo para o final para adicionar novo quarto
    fseek(arquivo, 0, SEEK_END);

    printf("Quantidade de hospedes: ");
    scanf("%d", &quarto.quantidadeHospedes);
    printf("Valor da diaria: ");
    scanf("%f", &quarto.valorDiaria);
    strcpy(quarto.status, "desocupado");

    fwrite(&quarto, sizeof(Quarto), 1, arquivo);
    fclose(arquivo);
    printf("Quarto cadastrado com sucesso!\n");
}

void cadastrarEstadia() {
    Estadia estadia;
    Quarto quarto;
    Cliente cliente;
    FILE *arquivoEstadias = fopen("estadias.bin", "ab+");
    FILE *arquivoQuartos = fopen("quartos.bin", "rb+");
    FILE *arquivoClientes = fopen("clientes.bin", "rb");

    if (arquivoEstadias == NULL || arquivoQuartos == NULL || arquivoClientes == NULL) {
        printf("Erro ao abrir arquivos.\n");
        return;
    }

    printf("Codigo da estadia: ");
    scanf("%d", &estadia.codigo);

    // Verifica se a estadia j� existe
    Estadia estadiaExistente;
    int estadiaEncontrada = 0;
    while (fread(&estadiaExistente, sizeof(Estadia), 1, arquivoEstadias)) {
        if (estadiaExistente.codigo == estadia.codigo) {
            estadiaEncontrada = 1;
            break;
        }
    }

    if (estadiaEncontrada) {
        printf("Estadia j� cadastrada com este c�digo.\n");
        fclose(arquivoEstadias);
        fclose(arquivoQuartos);
        fclose(arquivoClientes);
        return;
    }

    // Move o ponteiro de arquivo para o final para adicionar nova estadia
    fseek(arquivoEstadias, 0, SEEK_END);

    printf("Data de entrada (dd/mm/aaaa): ");
    scanf(" %[^\n]", estadia.dataEntrada);
    printf("Data de saida (dd/mm/aaaa): ");
    scanf(" %[^\n]", estadia.dataSaida);
    printf("Codigo do cliente: ");
    scanf("%d", &estadia.codigoCliente);

    // Verifica se o cliente existe
    int clienteEncontrado = 0;
    while (fread(&cliente, sizeof(Cliente), 1, arquivoClientes)) {
        if (cliente.codigo == estadia.codigoCliente) {
            clienteEncontrado = 1;
            break;
        }
    }

    if (!clienteEncontrado) {
        printf("Cliente nao encontrado.\n");
        fclose(arquivoClientes);
        fclose(arquivoQuartos);
        fclose(arquivoEstadias);
        return;
    }

    printf("Numero do quarto: ");
    scanf("%d", &estadia.numeroQuarto);

    // Verifica se o quarto existe e est� desocupado
    int quartoEncontrado = 0;
    long pos;
    while (fread(&quarto, sizeof(Quarto), 1, arquivoQuartos)) {
        if (quarto.numero == estadia.numeroQuarto && strcmp(quarto.status, "desocupado") == 0) {
            quartoEncontrado = 1;
            pos = ftell(arquivoQuartos);
            break;
        }
    }

    if (!quartoEncontrado) {
        printf("Quarto nao encontrado ou ocupado.\n");
        fclose(arquivoClientes);
        fclose(arquivoQuartos);
        fclose(arquivoEstadias);
        return;
    }

    // Atualiza o status do quarto para ocupado
    fseek(arquivoQuartos, pos - sizeof(Quarto), SEEK_SET);
    strcpy(quarto.status, "ocupado");
    fwrite(&quarto, sizeof(Quarto), 1, arquivoQuartos);

    // Calcula a quantidade de di�rias, assumimos que a data de entrada e sa�da est�o no formato dd/mm/aaaa
    int diaEntrada, mesEntrada, anoEntrada, diaSaida, mesSaida, anoSaida;
    sscanf(estadia.dataEntrada, "%d/%d/%d", &diaEntrada, &mesEntrada, &anoEntrada);
    sscanf(estadia.dataSaida, "%d/%d/%d", &diaSaida, &mesSaida, &anoSaida);
    estadia.quantidadeDiarias = (diaSaida - diaEntrada) + 1;

    fwrite(&estadia, sizeof(Estadia), 1, arquivoEstadias);
    fclose(arquivoClientes);
    fclose(arquivoQuartos);
    fclose(arquivoEstadias);
    printf("Estadia cadastrada com sucesso!\n");
}

void darBaixaEstadia() {
    Estadia estadia;
    Quarto quarto;
    FILE *arquivoEstadias = fopen("estadias.bin", "rb");
    FILE *arquivoQuartos = fopen("quartos.bin", "rb+");
    FILE *arquivoTemp = fopen("temp.bin", "wb");

    if (arquivoEstadias == NULL || arquivoQuartos == NULL || arquivoTemp == NULL) {
        printf("Erro ao abrir arquivos.\n");
        return;
    }

    int codigoEstadia;
    printf("C�digo da estadia para dar baixa: ");
    scanf("%d", &codigoEstadia);

    int estadiaEncontrada = 0;
    while (fread(&estadia, sizeof(Estadia), 1, arquivoEstadias)) {
        if (estadia.codigo == codigoEstadia) {
            estadiaEncontrada = 1;
        } else {
            fwrite(&estadia, sizeof(Estadia), 1, arquivoTemp);
        }
    }

    fclose(arquivoEstadias);
    fclose(arquivoTemp);

    if (!estadiaEncontrada) {
        printf("Estadia nao encontrada.\n");
        fclose(arquivoQuartos);
        return;
    }

    remove("estadias.bin");
    rename("temp.bin", "estadias.bin");

    // Calcula o valor total a ser pago
    float valorTotal = 0;
    long pos;
    while (fread(&quarto, sizeof(Quarto), 1, arquivoQuartos)) {
        if (quarto.numero == estadia.numeroQuarto) {
            valorTotal = quarto.valorDiaria * estadia.quantidadeDiarias;
            pos = ftell(arquivoQuartos);
            break;
        }
    }

    // Atualiza o status do quarto para desocupado
    fseek(arquivoQuartos, pos - sizeof(Quarto), SEEK_SET);
    strcpy(quarto.status, "desocupado");
    fwrite(&quarto, sizeof(Quarto), 1, arquivoQuartos);

    printf("Valor total a ser pago: R$ %.2f\n", valorTotal);
    fclose(arquivoQuartos);
    printf("Baixa da estadia realizada com sucesso!\n");
}

void pesquisarCliente() {
    Cliente cliente;
    FILE *arquivo = fopen("clientes.bin", "rb");

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo de clientes.\n");
        return;
    }

    int codigo;
    char nome[50];
    printf("Digite o codigo do cliente (ou 0 para buscar por nome): \n");
    scanf("%d", &codigo);
    getchar();

    while (fread(&cliente, sizeof(Cliente), 1, arquivo)) {
        if (codigo != 0 && cliente.codigo == codigo) {
            printf("Codigo: %d\n", cliente.codigo);
            printf("Nome: %s\n", cliente.nome);
            printf("Endere�o: %s\n", cliente.endereco);
            printf("Telefone: %s\n", cliente.telefone);
            fclose(arquivo);
            return;
        } else if (codigo == 0) {
            printf("Digite o nome do cliente: \n");
            fgets(nome, sizeof(nome), stdin);
            nome[strcspn(nome, "\n")] = '\0';

            if (strcmp(cliente.nome, nome) == 0) {
                printf("Codigo: %d\n", cliente.codigo);
                printf("Nome: %s\n", cliente.nome);
                printf("Endere�o: %s\n", cliente.endereco);
                printf("Telefone: %s\n", cliente.telefone);
                fclose(arquivo);
                return;
            }
        }
    }

    printf("Cliente n�o encontrado.\n");
    fclose(arquivo);
}

void pesquisarFuncionario() {
    Funcionario funcionario;
    FILE *arquivo = fopen("funcionarios.bin", "rb");

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo de funcion�rios.\n");
        return;
    }

    int codigo;
    char nome[50];
    printf("Digite o c�digo do funcion�rio (ou 0 para buscar por nome): \n");
    scanf("%d", &codigo);
    getchar();

    while (fread(&funcionario, sizeof(Funcionario), 1, arquivo)) {
        if (codigo != 0 && funcionario.codigo == codigo) {
            printf("Codigo: %d\n", funcionario.codigo);
            printf("Nome: %s\n", funcionario.nome);
            printf("Telefone: %s\n", funcionario.telefone);
            printf("Cargo: %s\n", funcionario.cargo);
            printf("Sal�rio: %.2f\n", funcionario.salario);
            fclose(arquivo);
            return;
        } else if (codigo == 0) {
            printf("Digite o nome do funcion�rio: \n");
            fgets(nome, sizeof(nome), stdin);
            nome[strcspn(nome, "\n")] = '\0';

            if (strcmp(funcionario.nome, nome) == 0) {
                printf("Codigo: %d\n", funcionario.codigo);
                printf("Nome: %s\n", funcionario.nome);
                printf("Telefone: %s\n", funcionario.telefone);
                printf("Cargo: %s\n", funcionario.cargo);
                printf("Sal�rio: %.2f\n", funcionario.salario);
                fclose(arquivo);
                return;
            }
        }
    }

    printf("Funcion�rio n�o encontrado.\n");
    fclose(arquivo);
}

void mostrarEstadiasCliente() {
    Estadia estadia;
    Cliente cliente;
    FILE *arquivoEstadias = fopen("estadias.bin", "rb");
    FILE *arquivoClientes = fopen("clientes.bin", "rb");

    if (arquivoEstadias == NULL || arquivoClientes == NULL) {
        printf("Erro ao abrir arquivos.\n");
        return;
    }

    int codigo;
    char nome[50];
    printf("Digite o c�digo ou o nome do cliente: \n");
    scanf("%d", &codigo);
    getchar();
    if (codigo == 0) {
        fgets(nome, sizeof(nome), stdin);
        nome[strcspn(nome, "\n")] = '\0';
    }

    int clienteEncontrado = 0;
    while (fread(&cliente, sizeof(Cliente), 1, arquivoClientes)) {
        if (cliente.codigo == codigo || strcmp(cliente.nome, nome) == 0) {
            clienteEncontrado = 1;
            break;
        }
    }

    if (!clienteEncontrado) {
        printf("Cliente n�o encontrado.\n");
        fclose(arquivoClientes);
        fclose(arquivoEstadias);
        return;
    }

    printf("Estadias do cliente %s:\n", cliente.nome);
    while (fread(&estadia, sizeof(Estadia), 1, arquivoEstadias)) {
        if (estadia.codigoCliente == cliente.codigo) {
            printf("Codigo da estadia: %d\n", estadia.codigo);
            printf("Data de entrada: %s\n", estadia.dataEntrada);
            printf("Data de sa�da: %s\n", estadia.dataSaida);
            printf("Quantidade de di�rias: %d\n", estadia.quantidadeDiarias);
            printf("N�mero do quarto: %d\n", estadia.numeroQuarto);
            printf("\n");
        }
    }

    fclose(arquivoClientes);
    fclose(arquivoEstadias);
}

void calcularPontosFidelidade() {
    Estadia estadia;
    Cliente cliente;
    FILE *arquivoEstadias = fopen("estadias.bin", "rb");
    FILE *arquivoClientes = fopen("clientes.bin", "rb");

    if (arquivoEstadias == NULL || arquivoClientes == NULL) {
        printf("Erro ao abrir arquivos.\n");
        return;
    }

    int codigo;
    char nome[50];
    printf("Digite o codigo ou o nome do cliente: \n");
    scanf("%d", &codigo);
    getchar();
    if (codigo == 0) {
        fgets(nome, sizeof(nome), stdin);
        nome[strcspn(nome, "\n")] = '\0';
    }

    int clienteEncontrado = 0;
    while (fread(&cliente, sizeof(Cliente), 1, arquivoClientes)) {
        if (cliente.codigo == codigo || strcmp(cliente.nome, nome) == 0) {
            clienteEncontrado = 1;
            break;
        }
    }

    if (!clienteEncontrado) {
        printf("Cliente nao encontrado.\n");
        fclose(arquivoClientes);
        fclose(arquivoEstadias);
        return;
    }

    int pontos = 0;
    while (fread(&estadia, sizeof(Estadia), 1, arquivoEstadias)) {
        if (estadia.codigoCliente == cliente.codigo) {
            pontos += estadia.quantidadeDiarias * 10;
        }
    }

    printf("Pontos de fidelidade do cliente %s: %d pontos\n", cliente.nome, pontos);
    fclose(arquivoClientes);
    fclose(arquivoEstadias);
}

int main() {
    inicializarArquivos();

    int opcao;

    do {
        printf("\nMenu Principal\n");
        printf("1. Cadastrar Cliente\n");
        printf("2. Cadastrar Funcionario\n");
        printf("3. Cadastrar Quarto\n");
        printf("4. Cadastrar Estadia\n");
        printf("5. Dar Baixa em Estadia\n");
        printf("6. Pesquisar Cliente\n");
        printf("7. Pesquisar Funcionario\n");
        printf("8. Mostrar Estadias do Cliente\n");
        printf("9. Calcular Pontos de Fidelidade\n");
        printf("10. Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                cadastrarCliente();
                break;
            case 2:
                cadastrarFuncionario();
                break;
            case 3:
                cadastrarQuarto();
                break;
            case 4:
                cadastrarEstadia();
                break;
            case 5:
                darBaixaEstadia();
                break;
            case 6:
                pesquisarCliente();
                break;
            case 7:
                pesquisarFuncionario();
                break;
            case 8:
                mostrarEstadiasCliente();
                break;
            case 9:
                calcularPontosFidelidade();
                break;
            case 10:
                printf("Saindo...\n");
                break;
            default:
                printf("Opcao invalida. Tente novamente.\n");
        }
    } while (opcao != 10);

    return 0;
}
